﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BlazorMobileTest
{
    public class CustDetails
    {
        public String CustName { get; set; }
    }
}
